#include "stdafx.h"
#include "Autor.h"
#include <string>
#include <iostream>


Autor::Autor(string a,string b){
	this->imie = a;
	this->nazwisko = b;

}


Autor::~Autor()
{
}
