// ConsoleApplication11.cpp : Defines the entry point for the console application.
//
#include <iostream>
#include "stdafx.h"
#include <string>
#include "Ksiazka.h"
#include "Autor.h"



using namespace std;



int main()
{
	//cout << "aaa" << endl;
	Ksiazka a1;
	Autor("Janusz", "Tracz");
	
	system("pause");
    return 0;
}

