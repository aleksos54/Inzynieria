#pragma once
#include <string>
#include <iostream>
using namespace std;
class Autor{

public:
	string imie;
	string nazwisko;

	Autor(string a,string b);
	~Autor();
};

